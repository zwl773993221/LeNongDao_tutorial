1. This scene sample can only be run when vi-isp-vpss-venc is running;
2. Different sensors have different configuration file in ini dir;

